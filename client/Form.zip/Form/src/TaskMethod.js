import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.min.js';
function TaskMethod({func1, func2}) {

const changeFunc1 = (Status) => {
    func1(Status);
}
const changeFunc2 = (Status) => {
    func2(Status);
}
    return (
        <div>
        <ul role="tablist" className="nav bg-light nav-pills rounded-pill nav-fill mb-3">
                    <li className="nav-item" onClick={() => {changeFunc1(1);changeFunc2(false)}}>
                      <a data-toggle="pill" href="#nav-tab-card" className="nav-link active rounded-pill">
                                          Ăn tại quán
                      </a>
                    </li>
                    <li className="nav-item" onClick={() => {changeFunc1(2);changeFunc2(false)}}>
                      <a data-toggle="pill" href="#nav-tab-card" className="nav-link active rounded-pill">                                             
                                          Mang về nhà
                      </a>
                    </li>
          </ul>
      </div>
        
    );
};
export default TaskMethod;
