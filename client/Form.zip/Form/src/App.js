import React, { useState } from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.min.js';
import StripeCheckout from 'react-stripe-checkout';
import Taskform1 from './Taskform1';
import Taskform2 from './Taskform2';
import TaskMethod from './TaskMethod';

function Home(){
    
const ChangeDisplay = (Status) => {
    SetisDisplayForm(Status);
}
const ChangeMethod = (Status) => {
    SetisDisplayMethod(Status);
}
const [isDisplayForm, SetisDisplayForm] = useState(-1)
// isDisplayForm = -1 -> form is hidden
// isDisplayForm = 1 -> display form1
// isDisplayForm = 2 -> dispaly form2

const elmTaskForm = isDisplayForm == -1 ? '': isDisplayForm == 1 ? <Taskform1 func1={ChangeDisplay} func2 = {ChangeMethod}/> : <Taskform2 func1={ChangeDisplay} func2 = {ChangeMethod}/>

const [isDisplayMethod, SetisDisplayMethod] = useState(true)
const elmTaskMethod = isDisplayMethod? <TaskMethod func1={ChangeDisplay} func2 = {ChangeMethod}/>:''
// isDisplayMethod = false -> method selection is hidden
// isDisplayMethod = true -> display methodSelection
    return (
        <div className="maincontainer">
          {elmTaskForm}
          {elmTaskMethod}
        </div>
  )
}
export default Home;