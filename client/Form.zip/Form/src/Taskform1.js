import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.min.js';
function Taskform1({func1, func2}) {

const changeFunc1 = (Status) => {
    func1(Status);
}
const changeFunc2 = (Status) => {
    func2(Status);
}

    return (
            <div className="container py-5">
                <div className="col-lg-7 mx-auto">
                    <div className="bg-white rounded-lg shadow-sm p-5">
                      <div className="close">
                            <i className="fas fa-times" onClick={() => {changeFunc1(-1); changeFunc2(true)}}>X</i>
                      </div>

                      <ul role="tablist" className="nav bg-light nav-pills rounded-pill nav-fill mb-3">
                        <li className="nav-item">
                          <a data-toggle="pill" href="#nav-tab-card" className="nav-link active rounded-pill">
                              Dịch vụ tại quán
                          </a>
                        </li>
                      </ul>

                      <div className="tab-content">
                        <div id="nav-tab-card" className="tab-pane fade show active">
                          <form role="form">
                            <div className="form-group">
                              <label htmlFor="username">Full name</label>
                              <input type="text" name="username" placeholder="User Name" required className="form-control" />
                            </div>
                            <div className="row">
                                <div className="col-sm-3">
                                    <div class="form-group">
                                      <label for="sel1">Chọn bàn:</label>
                                      <select class="form-control" id="sel1">
                                        <option>1</option>
                                        <option>2</option>
                                        <option>3</option>
                                        <option>4</option>
                                      </select>
                                    </div>
                                </div>
                            </div>
                            <button type="button" className="subscribe btn btn-primary btn-block rounded-pill shadow-sm"> Confirm  </button>
                          </form>
                        </div>
                        
                      </div>
                    </div>
                  </div>
                </div>
        
    );
};
export default Taskform1;
